from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        con = sqlite3.connect('database.db')
        cur = con.cursor()

        # VULNERABLE SQL
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        try:
            cur.execute(query)
            result = cur.fetchone()
            if result:
                msg = "✅ Login Successful"
            else:
                msg = "❌ Invalid Credentials"
        except Exception as e:
            msg = f"Error: {e}"
        con.close()

    return render_template("login.html", msg=msg)

if __name__ == '__main__':
    app.run(debug=True)
