import sqlite3

con = sqlite3.connect("app/database.db")
cur = con.cursor()
cur.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, password TEXT)")
cur.execute("INSERT INTO users (username, password) VALUES ('admin', 'admin123')")
con.commit()
con.close()
