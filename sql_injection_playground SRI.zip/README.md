# SQL Injection Playground with Detection Engine

## Features
- Vulnerable login form using Flask + SQLite
- SQL Injection attack simulation
- Python-based SQLi detector with logging
- Safe version can be created using parameterized queries

## Setup

```bash
pip install -r requirements.txt
python setup_db.py
cd app
python app.py
```

Run Detector:

```bash
cd detector
python sqli_detector.py
```
